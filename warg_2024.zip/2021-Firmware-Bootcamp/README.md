# Embedded-Bootcamp

## Welcome to the WARG Firmware Bootcamp! 

Full instructions can be found on the [Bootcamp Confluence Page](https://uwarg-docs.atlassian.net/wiki/spaces/BOOT/pages/1997373445/2021+Firmware+Bootcamp).

This repository contains a basic STM32IDE project that will be modified to complete the bootcamp.

For git specific questions and direction please visit our [Git Tutorial](https://uwarg-docs.atlassian.net/wiki/spaces/TUT/pages/1544257554/Git+and+GitHub+Tutorial).

